//
//  MultiplePicker.swift
//  QQ
//
//  Created by 구민규 on 5/11/24.
//

import SwiftUI

struct MultiplePicker: View {
    let fruits = ["토익", "일본문화", "동남아역사", "역사와리더쉽", "컴퓨터구조", "이산수학"]
        @State private var selectedFruits: Set<String> = []
    var body: some View {
        NavigationView {
                    List {
                        ForEach(fruits, id: \.self) { fruit in
                            Multiplechoice(title: fruit, isSelected: selectedFruits.contains(fruit)) {
                                if selectedFruits.contains(fruit) {
                                    selectedFruits.remove(fruit)
                                } else {
                                    selectedFruits.insert(fruit)
                                }
                            }
                        }
                    }
                    .navigationTitle("문제 과목 선택")
                }
    }
}

#Preview {
    MultiplePicker()
}
