//
//  Multiplechoice.swift
//  QQ
//
//  Created by 구민규 on 5/11/24.
//

import SwiftUI

struct Multiplechoice: View {
    var title: String
        var isSelected: Bool
        var action: () -> Void

    var body: some View {
        Button(action: action) {
                   HStack {
                       Text(title)
                       Spacer()
                       if isSelected {
                           Image(systemName: "checkmark.square")
                       }
                       else{
                           
                           Image(systemName: "square")
                           
                       }
                   }.tint(.black)
               }
    }
}

//#Preview {
//    Multiplechoice(title: "hello", isSelected: true, action: <#() -> Void#>)
//}
