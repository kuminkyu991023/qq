//
//  SelectingPdf.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct SelectingPdf: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 25)
            
            .stroke(lineWidth: 0)
            
            .frame(height:300)
           
        
            .overlay(
                VStack{
                    Spacer()
                    Image(systemName: "folder").font(.system(size: 60))
                        .foregroundColor(.gray.opacity(0.5))
                        .padding(5)
                    
                    Spacer()
                    
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        Text("PDF 업로딩")
                            .frame(maxWidth:250)
                          
                            //.foregroundStyle(Color.white)
                            
                            
                            .font(.system(size: 24))
                            .fontWeight(.semibold)
                    })
                    
                    .controlSize(.large)
                       
                        .tint(Color("color1"))
                }.frame(height:200)
            
            )
    }
}

#Preview {
    SelectingPdf()
}
