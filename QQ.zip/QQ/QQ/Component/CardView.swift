//
//  CardView.swift
//  QQ
//
//  Created by 구민규 on 5/11/24.
//

import SwiftUI

struct CardView: View {
    var Question:String
    @State private var offset = CGSize.zero
    @State private var color:Color = .black
    
    var body: some View {
        ZStack{
            
            Rectangle()
                .frame(width:350,height: 350*1.3)
                .border(.white,width: 6)
                .cornerRadius(4)
                .foregroundColor(color.opacity(0.9))
                .shadow(radius:4)
            HStack{
                Text(Question)
                    
                    .font(.title)
                    .foregroundColor(.white)
                    .bold()
                    
                    
            }
        }
        .offset(x:offset.width,y:offset.height * 0.4)
        .rotationEffect(.degrees(Double(offset.width/60)))
        .gesture(
            DragGesture()
                .onChanged{
                    gesture in offset = gesture.translation
                    withAnimation{
                        changeColor(width: offset.width)
                        
                    }
                    
                }.onEnded{
                    _ in
                    withAnimation{
                        swipeCard(width: offset.width)
                        changeColor(width: offset.width)
                        
                    }
                }
        )
    }
    func swipeCard(width: CGFloat){
        switch width {
        case -500...(-150):
            offset = CGSize(width:-500,height:0)
            
        case 150 ... 500:
            offset = CGSize(width: 500, height: 0)
        default:
            offset = .zero
        }
        
    }
    func changeColor(width:CGFloat){
        switch width {
        case -500...(-130):
            color = .red
        case 130...500:
            color = .green
        default:
            color = .black
            
        }
        
    }
}

#Preview {
    CardView(Question: "6.25전쟁이 일어난 년도는 1950년이다.")
}
