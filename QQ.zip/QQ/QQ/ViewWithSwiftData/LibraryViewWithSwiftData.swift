//
//  LibraryViewWithSwiftData.swift
//  QQ
//
//  Created by 구민규 on 5/12/24.
//

import SwiftUI
import SwiftData

struct LibraryViewWithSwiftData: View {
    @Query var questionDatas:[QuestionData]
    @Environment(\.modelContext) var modelContext
    @State private var path = [QuestionData]()
    
    var body: some View {
        NavigationStack(path:$path){
            
            List{
                ForEach(questionDatas){
                    questionData in
                    VStack(alignment:.leading){
                        Text(questionData.name)
                            .font(.headline)
                        Text(questionData.date.formatted(date: .long,time:.omitted))
                            .font(.callout)
                    }
                }.onDelete(perform: deletDestination)
                
            }
            
            .navigationTitle("라이브러리")
            .navigationDestination(for: QuestionData.self, destination: EditLibraryViewWithSwiftData.init)
          
                .toolbar{
                    ToolbarItem(placement: .topBarTrailing){
                        Button(action: {
                            addSamples()
                        }, label: {
                            Image(systemName: "plus").tint(.black)
                        })
                    }
                }
        }
        
    }
    func addSamples(){
       let questionData = QuestionData()
        modelContext.insert(questionData)
        path = [questionData]
    }
    func deletDestination(_ indexSet:IndexSet){
        for index in indexSet{
            let destination = questionDatas[index]
            modelContext.delete(destination)
        }
    }
    
    
}

#Preview {
    LibraryViewWithSwiftData()
}
