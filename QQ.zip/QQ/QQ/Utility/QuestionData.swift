//
//  QuestionData.swift
//  QQ
//
//  Created by 구민규 on 5/12/24.
//


import Foundation
import SwiftData

@Model
class QuestionData{
    
    var name:String
    var question:String
    var date:Date
    var answer:String
    var category:String
    init(name: String = "", question: String = "", date: Date = .now, answer: String = "", category: String = "") {
        self.name = name
        self.question = question
        self.date = date
        self.answer = answer
        self.category = category
    }
    
}
