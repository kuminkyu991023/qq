//
//  UploadingFileView.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct UploadingFileView: View {
    @Binding var UploadingFileView:Bool
    @State var fileText = "제목을 입력하세요"
    @State var pickerselection = "토익"
    var ClassName = ["AI 활용표현과 문제해결", "토익","동남아 역사","역사와 리더쉽","이산수학","일본어","중국문화"]
    
    var body: some View {
        
       
        
            
            NavigationStack{
                VStack{
                    
                    
                    
                    SelectingPdf()
                        
                        .padding()
                       
                    
                    
                        
                            TextField("", text: $fileText)
                                .foregroundColor(fileText == "제목을 입력하세요" ? .gray : .black)
                                .padding(20)
                                .background(
                                    RoundedRectangle(cornerRadius: 10)
                                        .stroke(lineWidth: 0.5)
                                )
                                .padding()
                        
                        
                            Picker("카테고리",selection: $pickerselection){
                                ForEach(ClassName,id:\.self){
                                    name in Text(name)
                                }
                                
                            }.pickerStyle(.wheel)
                        .background(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(lineWidth: 0.5)
                        )
                        .padding()
                            
                        
                    
                    Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                        RoundedRectangle(cornerRadius: 8)
                            .frame(height: 60)
                            .overlay(
                            Text("제출하기")
                                .font(.system(size: 18))
                                .fontWeight(.bold)
                                .foregroundStyle(Color.white)
                            )
                    })
                    .padding()
                    
                    
                    .toolbar{
                        
                        ToolbarItem(placement: .topBarLeading){
                            
                            Button(action: {
                                
                                UploadingFileView = false
                                
                            }, label: {
                                Image(systemName: "xmark").foregroundColor(.black)
                            })
                        }
                    }
                    
                    
                    
                    
                    
                }}
    }
}

//#Preview {
  //  UploadingFileView(UploadingFileView: true)
//}
