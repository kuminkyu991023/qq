//
//  HomeView.swift
//  QQ
//
//  Created by 구민규 on 5/9/24.
//

import SwiftUI

struct HomeView: View {
    var body: some View {
        Form{
            Section(){
                Text("오늘 해결 한 문제 수 입니다.")
                Text("59문제 해결").font(.system(size: 24))
                
            }.listRowSeparator(.hidden)
                                Section(header:Text("과목").font(.system(size: 24)).foregroundStyle(Color.black)){
                Text("오늘 문제 푼 경황입니다.").fontWeight(.medium)
                subjectgraph()
                    .frame(height:250)
                
            }
            Section(header:Text("이번주").font(.system(size: 24)).foregroundStyle(Color.black)){
                Text("이번 주 문제 푼 경향입니다")
                    .fontWeight(.medium)
                dailycountergraph()
                    .frame(height:250)
                
            }
        }
    }
}

#Preview {
    HomeView()
}
