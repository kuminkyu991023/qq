//
//  shortsView.swift
//  QQ
//
//  Created by 구민규 on 5/11/24.
//

import SwiftUI

struct shortsView: View {
    private var questions:[String] = ["6.25전쟁이 일어난 년도는 1950년이다.","print(\(5) == 5)의 출력 값은 true이다","print(5+5)의 출력 값은 10이 아니다." ]
    var body: some View {
        VStack{
            Spacer()
            ZStack{
                
                ForEach(questions,id:\.self){
                    person in CardView(Question: person)
                    
                }
            }
            Spacer()
            
            
            
        }
    }
}

#Preview {
    shortsView()
}
