//
//  MakingCategoryView.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct MakingCategoryView: View {
    @State private var FileName = "새로운 과목"
    @State private var DateNow = Date.now
    @State private var color = Color.blue
    @Binding  var makingCategoryView:Bool
    var body: some View {
        NavigationStack{
            Form{
                Section(header:Text("제목과 날짜")){
                    HStack{TextField("", text: $FileName).foregroundColor(FileName == "새로운 과목" ? .gray:.black)
                        DatePicker("", selection: $DateNow,displayedComponents: .date).datePickerStyle(.automatic)}
                }
                Section{
                    
                   ColorPicker("색상 선택",selection: $color)
                    
                }
                
            }.toolbar{
                
                ToolbarItem(placement:.topBarLeading){
                    Button(action: {
                        
                        makingCategoryView.toggle()
                    }
                           , label: {
                        Text("취소")
                    })
                    
                }
                ToolbarItemGroup(placement: .principal) {
                                    Text("새로운 카테고리").bold() // 여기에 원하는 제목을 넣습니다.
                                }
                ToolbarItem(placement:.topBarTrailing){
                    Button(action: {
                        makingCategoryView.toggle()
                        
                    }, label: {
                        Text("완료")
                    })
                    
                }
            }
        }
            
    }
}


