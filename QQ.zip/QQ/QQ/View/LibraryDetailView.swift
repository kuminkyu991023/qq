//
//  LibraryDetailView.swift
//  QQ
//
//  Created by 구민규 on 5/10/24.
//

import SwiftUI

struct LibraryDetailView: View {
    @State var showingRefactoryView = false
    @State var week = ["1 주차","2 주차","3 주차","4 주차","5 주차","6 주차","7 주차"]
    var body: some View {
        NavigationStack{
            List{
                ForEach(week,id:\.self){
                    
                    name in Text(name).font(.system(size: 20)).padding()
                }
                .swipeActions{
                    Button(role:.destructive){
                        
                        print("Delete")
                    }label: {
                        Text("삭제")
                    }
                    
                    
                    
                }
                .swipeActions(edge:.leading,allowsFullSwipe: false){
                    Button(role:.none){
                        showingRefactoryView = true
                        print(showingRefactoryView)
                    }label: {
                        Text("수정")
                    }.tint(.blue)
                    
                }
                
                
                
                
                
            }
            .sheet(isPresented: $showingRefactoryView){
                
                RefactoryView()
                    .presentationDetents([.fraction(0.3)])
            }
        }
            }
}

#Preview {
    LibraryDetailView()
}
